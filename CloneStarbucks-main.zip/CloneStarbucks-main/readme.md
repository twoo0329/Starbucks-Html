# Starbucks Clone
<h3>Site da Starbucks para práticar CSS grid. Starbucks website for css grid practice purposes. </h3>

<p align="center">
https://lucimarasouzah.github.io/CloneStarbucks/
</p>

<h3 align="center">Thanks! Obrigada ^^</h3>
